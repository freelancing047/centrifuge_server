package com.csi.gwt.launcher;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import lombok.Getter;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.beust.jcommander.ParameterException;
import com.google.gwt.dev.DevMode;

public class DevModeLauncher {

    @Parameter(names = { "-p", "--port" }, description = "port to listen on, default 7000")
    @Getter
    private int port = 7000;

    @Parameter(names = { "-c", "--codeServerPort" }, description = "coder server port to listen on, default 8000")
    @Getter
    private int codeServerPort = 8000;

    @Parameter(names = { "-s", "--startupURL" }, description = "startup URL", required = true)
    @Getter
    private String startupUrl;

    @Parameter(names = { "-w", "--warPath" }, description = "war directory", required = true)
    @Getter
    private String warPath;

    @Parameter(names = { "-m", "--module" }, description = "gwt module name", required = true)
    @Getter
    private List<String> modules;

    @Parameter(names = { "-x", "--contextPath" }, description = "context path for webapp, default /")
    @Getter
    private String contextPath = "/";

    @Parameter(names = { "-d", "--workDir" }, description = "compiler working dir")
    @Getter
    private String compilerWorkingDir;

    @Parameter(names = { "-g", "--gen" }, description = "directory for writing generated files")
    @Getter
    private String generatedFilesDir;

    @Parameter(names = { "-b", "--bindAddress" }, description = "bind address, default 0.0.0.0 for all")
    @Getter
    private String bindAddress = "0.0.0.0";

    @Parameter(names = "--help", help = true)
    @Getter
    private boolean help;

    public void start() {
        List<String> params = new ArrayList<String>();
        // Internal
        params.add("-server");
        params.add(JettyServletContainerLauncher.class.getName());

        // Required
        params.add("-startupUrl");
        params.add(getStartupUrl());
        params.add("-war");
        params.add(getWarPath());

        // Optional but important
        params.add("-port");
        params.add(Integer.toString(getPort()));
        params.add("-codeServerPort");
        params.add(Integer.toString(getCodeServerPort()));

        // See comment in JettyServletContainerLauncher for this uglyness.
        JettyServletContainerLauncher.setContextPath(getContextPath());

        if (StringUtils.isNotBlank(getCompilerWorkingDir())) {
            params.add("-workDir");
            params.add(getCompilerWorkingDir());
        }
        if (StringUtils.isNotBlank(getGeneratedFilesDir())) {
            params.add("-gen");
            params.add(getGeneratedFilesDir());
        }
        if (StringUtils.isNotBlank(getBindAddress())) {
            params.add("-bindAddress");
            params.add(getBindAddress());
        }

//         params.add("-logLevel");
//         params.add("TRACE");
        params.add("-logdir");
        params.add("c:/temp/gwtlogdir");

        // Modules are required but are added to the end.
        for (String module : getModules()) {
            params.add(module);
        }

        DevMode.main(params.toArray(new String[] {}));
    }

    public static void main(String[] args) {
        DevModeLauncher server = new DevModeLauncher();
        JCommander commander = new JCommander(server);
        try {
            commander.parse(args);
            server.start();
        } catch (ParameterException e) {
            System.err.println(e.getMessage());
            commander.usage();
        }
    }

}
