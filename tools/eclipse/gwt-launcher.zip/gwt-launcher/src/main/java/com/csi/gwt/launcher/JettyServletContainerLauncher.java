package com.csi.gwt.launcher;

import java.io.File;
import java.net.BindException;

import lombok.Getter;
import lombok.Setter;

import com.google.gwt.core.ext.ServletContainer;
import com.google.gwt.core.ext.ServletContainerLauncher;
import com.google.gwt.core.ext.TreeLogger;

public class JettyServletContainerLauncher extends ServletContainerLauncher {

	private static final int MAX_IDLE_TIME = 300000;

	// There is no elegant non-static way to pass this as DevMode creates an
	// instance of the launcher and
	// GWT hasn't promised any API for DevMode beyond main(String[] args).
	// aarggh :-(
	@Getter
	@Setter
	private static String contextPath;

	@Override
	public ServletContainer start(TreeLogger logger, int port, File appRootDir)
			throws BindException, Exception {
		JettyServletContainer core = new JettyServletContainer();
		core.setPort(port);
		core.setContextPath(getContextPath());
		core.setAppRootDir(appRootDir);
		core.setTreeLogger(logger);

		core.setMaxIdleTime(MAX_IDLE_TIME);
		core.start();
		return core;
	}

}
